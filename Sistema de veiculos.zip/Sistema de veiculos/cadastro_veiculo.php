<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: index.php');
    exit;
}

if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Veículo - Sistema Veículos</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="dashboard-container">
        <div class="header">
            <h1>📝 Cadastrar Veículo</h1>
            <div class="user-info">
                <span>Usuário: <strong><?= htmlspecialchars($_SESSION['user']) ?></strong></span>
                <a href="dashboard.php" class="btn btn-secondary">← Voltar</a>
                <a href="logout.php" class="btn btn-secondary">🚪 Sair</a>
            </div>
        </div>

        <div class="form-container">
            <form action="salvar_veiculo.php" method="post">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="marca">Marca *</label>
                        <select id="marca" name="marca" required>
                            <option value="">Selecione uma marca</option>
                            <option value="Chevrolet">Chevrolet</option>
                            <option value="Ford">Ford</option>
                            <option value="Fiat">Fiat</option>
                            <option value="Volkswagen">Volkswagen</option>
                            <option value="Toyota">Toyota</option>
                            <option value="Honda">Honda</option>
                            <option value="Hyundai">Hyundai</option>
                            <option value="Renault">Renault</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="modelo">Modelo *</label>
                        <input type="text" id="modelo" name="modelo" required placeholder="Ex: Onix, Civic, Gol...">
                    </div>

                    <div class="form-group">
                        <label for="cor">Cor *</label>
                        <input type="text" id="cor" name="cor" required placeholder="Ex: Preto, Branco, Prata...">
                    </div>

                    <div class="form-group">
                        <label for="proprietario">Proprietário *</label>
                        <input type="text" id="proprietario" name="proprietario" required placeholder="Nome do proprietário">
                    </div>

                    <div class="form-group">
                        <label for="placa">Placa *</label>
                        <input type="text" id="placa" name="placa" required 
                               pattern="[A-Z]{3}-[0-9]{4}" 
                               placeholder="ABC-1234" 
                               title="Formato: ABC-1234">
                    </div>

                    <div class="form-group">
                        <label for="ano_fabricacao">Ano de Fabricação *</label>
                        <input type="number" id="ano_fabricacao" name="ano_fabricacao" 
                               min="1900" max="<?= date('Y') ?>" 
                               required placeholder="<?= date('Y') ?>">
                    </div>
                </div>

                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                
                <div style="display: flex; gap: 1rem; margin-top: 2rem;">
                    <button type="submit" class="btn btn-primary btn-block">
                        💾 Salvar Veículo
                    </button>
                    <a href="dashboard.php" class="btn btn-secondary">Cancelar</a>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Máscara para placa
        document.getElementById('placa').addEventListener('input', function(e) {
            let value = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
            if (value.length > 3) {
                value = value.substring(0, 3) + '-' + value.substring(3, 7);
            }
            e.target.value = value;
        });
    </script>
</body>
</html>