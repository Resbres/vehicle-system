<?php
// Configurações do banco de dados
$DB_HOST = '127.0.0.1';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'sistema_veiculos';
$DB_PORT = 3306;

// Criar conexão
$mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME, $DB_PORT);

// Verificar conexão
if ($mysqli->connect_errno) {
    error_log("Erro de conexão MySQL: " . $mysqli->connect_error);
    die("Erro no sistema. Entre em contato com o administrador.");
}

// Definir charset
$mysqli->set_charset('utf8mb4');

// Timezone
date_default_timezone_set('America/Sao_Paulo');
?>