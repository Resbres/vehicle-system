<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: index.php');
    exit;
}

require 'db.php';

// CSRF para exclusão
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete'])) {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        die('Requisição inválida.');
    }
    
    $idDel = intval($_POST['delete']);
    $stmt = $mysqli->prepare("DELETE FROM veiculos WHERE id = ?");
    $stmt->bind_param('i', $idDel);
    
    if ($stmt->execute()) {
        $_SESSION['success_message'] = 'Veículo excluído com sucesso!';
    } else {
        $_SESSION['error_message'] = 'Erro ao excluir veículo.';
    }
    $stmt->close();
    
    header('Location: dashboard.php');
    exit;
}

// Buscar veículos
$result = $mysqli->query("SELECT * FROM veiculos ORDER BY id DESC");
$totalVeiculos = $result->num_rows;

if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
}

// Mensagens de sucesso/erro
$success_msg = $_SESSION['success_message'] ?? '';
$error_msg = $_SESSION['error_message'] ?? '';
unset($_SESSION['success_message'], $_SESSION['error_message']);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Sistema Veículos</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary: #2563eb;
            --primary-dark: #1d4ed8;
            --secondary: #64748b;
            --success: #10b981;
            --danger: #ef4444;
            --warning: #f59e0b;
            --light: #f8fafc;
            --dark: #1e293b;
            --border: #e2e8f0;
            --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            line-height: 1.6;
            color: var(--dark);
            padding: 20px;
        }

        .dashboard-container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .header {
            background: white;
            padding: 1.5rem 2rem;
            border-radius: 12px;
            box-shadow: var(--shadow);
            margin-bottom: 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .header h1 {
            color: var(--dark);
            font-size: 2rem;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 6px;
            font-size: 0.95rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            font-family: inherit;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-1px);
            box-shadow: var(--shadow);
        }

        .btn-secondary {
            background: var(--secondary);
            color: white;
        }

        .btn-secondary:hover {
            background: #475569;
        }

        .btn-success {
            background: var(--success);
            color: white;
        }

        .btn-danger {
            background: var(--danger);
            color: white;
        }

        .btn-danger:hover {
            background: #dc2626;
        }

        .btn-sm {
            padding: 0.5rem 1rem;
            font-size: 0.85rem;
        }

        /* Stats */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: white;
            padding: 1.5rem;
            border-radius: 12px;
            box-shadow: var(--shadow);
            text-align: center;
        }

        .stat-card h3 {
            color: var(--secondary);
            font-size: 0.9rem;
            margin-bottom: 0.5rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .stat-card .number {
            font-size: 2rem;
            font-weight: bold;
            color: var(--primary);
        }

        /* Table */
        .table-container {
            background: white;
            border-radius: 12px;
            box-shadow: var(--shadow);
            overflow: hidden;
            margin-bottom: 2rem;
        }

        .table-header {
            padding: 1.5rem;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .table-header h2 {
            color: var(--dark);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid var(--border);
        }

        th {
            background: var(--light);
            font-weight: 600;
            color: var(--dark);
            text-transform: uppercase;
            font-size: 0.85rem;
            letter-spacing: 0.5px;
        }

        tbody tr {
            transition: background-color 0.2s;
        }

        tbody tr:hover {
            background: #f8fafc;
        }

        /* Color preview */
        .color-preview {
            display: inline-block;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin-right: 8px;
            vertical-align: middle;
            border: 1px solid #ddd;
        }

        /* Actions */
        .actions {
            display: flex;
            gap: 0.5rem;
        }

        .delete-form {
            display: inline;
        }

        /* Alerts */
        .alert {
            padding: 1rem;
            border-radius: 6px;
            margin-bottom: 1rem;
            border: 1px solid transparent;
        }

        .alert-success {
            background: #f0fdf4;
            border-color: #bbf7d0;
            color: var(--success);
        }

        .alert-error {
            background: #fef2f2;
            border-color: #fecaca;
            color: var(--danger);
        }

        /* Empty state */
        .empty-state {
            padding: 3rem;
            text-align: center;
            color: var(--secondary);
        }

        .empty-state h3 {
            margin-bottom: 1rem;
            color: var(--dark);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                text-align: center;
            }
            
            .user-info {
                margin-left: 0;
                justify-content: center;
            }
            
            .table-header {
                flex-direction: column;
                text-align: center;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            table {
                font-size: 0.9rem;
            }
            
            th, td {
                padding: 0.75rem 0.5rem;
            }
            
            .actions {
                flex-direction: column;
            }
        }

        @media (max-width: 600px) {
            .table-container {
                overflow-x: auto;
            }
            
            table {
                min-width: 600px;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <div class="header">
            <h1>🚗 Sistema de Veículos</h1>
            <div class="user-info">
                <span>Olá, <strong><?= htmlspecialchars($_SESSION['user']) ?></strong></span>
                <a href="cadastro_veiculo.php" class="btn btn-success">➕ Novo Veículo</a>
                <a href="logout.php" class="btn btn-secondary">🚪 Sair</a>
            </div>
        </div>

        <?php if ($success_msg): ?>
            <div class="alert alert-success">
                ✅ <?= htmlspecialchars($success_msg) ?>
            </div>
        <?php endif; ?>

        <?php if ($error_msg): ?>
            <div class="alert alert-error">
                ❌ <?= htmlspecialchars($error_msg) ?>
            </div>
        <?php endif; ?>

        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total de Veículos</h3>
                <div class="number"><?= $totalVeiculos ?></div>
            </div>
            <div class="stat-card">
                <h3>Status do Sistema</h3>
                <div class="number" style="color: var(--success);">✅ Online</div>
            </div>
            <div class="stat-card">
                <h3>Última Atualização</h3>
                <div class="number" style="font-size: 1.2rem;"><?= date('d/m/Y H:i') ?></div>
            </div>
        </div>

        <div class="table-container">
            <div class="table-header">
                <h2>📋 Veículos Cadastrados</h2>
                <span><?= $totalVeiculos ?> veículo(s) encontrado(s)</span>
            </div>

            <?php if ($totalVeiculos > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Marca</th>
                            <th>Modelo</th>
                            <th>Cor</th>
                            <th>Proprietário</th>
                            <th>Placa</th>
                            <th>Ano</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><strong>#<?= $row['id'] ?></strong></td>
                            <td><?= htmlspecialchars($row['marca']) ?></td>
                            <td><?= htmlspecialchars($row['modelo']) ?></td>
                            <td>
                                <span class="color-preview" style="background: <?= htmlspecialchars($row['cor']) ?>;"></span>
                                <?= htmlspecialchars($row['cor']) ?>
                            </td>
                            <td><?= htmlspecialchars($row['proprietario']) ?></td>
                            <td><strong style="font-family: monospace;"><?= htmlspecialchars($row['placa']) ?></strong></td>
                            <td><?= $row['ano_fabricacao'] ?></td>
                            <td>
                                <form method="post" class="delete-form" onsubmit="return confirm('Tem certeza que deseja excluir o veículo <?= htmlspecialchars($row['placa']) ?>?')">
                                    <input type="hidden" name="delete" value="<?= $row['id'] ?>">
                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                                    <button type="submit" class="btn btn-danger btn-sm">🗑️ Excluir</button>
                                </form>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="empty-state">
                    <h3>Nenhum veículo cadastrado</h3>
                    <p>Comece cadastrando seu primeiro veículo!</p>
                    <a href="cadastro_veiculo.php" class="btn btn-primary" style="margin-top: 1rem;">➕ Cadastrar Primeiro Veículo</a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // Confirmação de exclusão
        document.querySelectorAll('.delete-form').forEach(form => {
            form.addEventListener('submit', function(e) {
                if (!confirm('Tem certeza que deseja excluir este veículo?')) {
                    e.preventDefault();
                }
            });
        });
    </script>
</body>
</html>
<?php
$result->close();
$mysqli->close();
?>