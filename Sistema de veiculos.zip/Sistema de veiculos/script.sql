-- Criar banco de dados
CREATE DATABASE IF NOT EXISTS sistema_veiculos 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

-- Usar o banco
USE sistema_veiculos;

-- Apagar tabela se existir (para recomeçar do zero)
DROP TABLE IF EXISTS veiculos;

-- Criar tabela veiculos
CREATE TABLE veiculos (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  marca VARCHAR(50) NOT NULL,
  modelo VARCHAR(50) NOT NULL,
  cor VARCHAR(20) NOT NULL,
  proprietario VARCHAR(100) NOT NULL,
  placa VARCHAR(8) NOT NULL UNIQUE,
  ano_fabricacao YEAR NOT NULL,
  data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Inserir dados de exemplo (opcional)
INSERT INTO veiculos (marca, modelo, cor, proprietario, placa, ano_fabricacao) VALUES
('Chevrolet', 'Onix', 'Preto', 'João Silva', 'ABC-1D23', 2023),
('Ford', 'Ka', 'Branco', 'Maria Santos', 'DEF-4E56', 2022),
('Fiat', 'Argo', 'Prata', 'Pedro Oliveira', 'GHI-7F89', 2024);