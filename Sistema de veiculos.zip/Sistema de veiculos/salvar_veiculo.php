<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: index.php');
    exit;
}

require 'db.php';

// CSRF e método
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
    die('Requisição inválida.');
}

// Coletar e sanitizar dados
$marca = trim($_POST['marca'] ?? '');
$modelo = trim($_POST['modelo'] ?? '');
$cor = trim($_POST['cor'] ?? '');
$proprietario = trim($_POST['proprietario'] ?? '');
$placa = strtoupper(trim($_POST['placa'] ?? ''));
$ano = intval($_POST['ano_fabricacao'] ?? 0);

// Validações server-side
$errors = [];

// Marca
if ($marca === '') {
    $errors[] = 'Marca obrigatória.';
} elseif (!in_array($marca, ['Chevrolet', 'Ford', 'Fiat', 'Volkswagen', 'Toyota'])) {
    $errors[] = 'Marca inválida.';
}

// Modelo
if ($modelo === '') {
    $errors[] = 'Modelo obrigatório.';
} elseif (strlen($modelo) < 2 || strlen($modelo) > 50) {
    $errors[] = 'Modelo deve ter entre 2 e 50 caracteres.';
}

// Cor
if ($cor === '') {
    $errors[] = 'Cor obrigatória.';
} elseif (strlen($cor) < 2 || strlen($cor) > 20) {
    $errors[] = 'Cor deve ter entre 2 e 20 caracteres.';
}

// Proprietário
if ($proprietario === '') {
    $errors[] = 'Proprietário obrigatório.';
} elseif (strlen($proprietario) < 5 || strlen($proprietario) > 100) {
    $errors[] = 'Proprietário deve ter entre 5 e 100 caracteres.';
}

// Placa (formato Mercosul AAA-0A00)
if ($placa === '') {
    $errors[] = 'Placa obrigatória.';
} elseif (!preg_match('/^[A-Z]{3}-[0-9][A-Z0-9][0-9]{2}$/', $placa)) {
    $errors[] = 'Placa no formato inválido. Use: AAA-0A00 (Mercosul).';
}

// Ano
if ($ano < 1980 || $ano > 2025) {
    $errors[] = 'Ano deve estar entre 1980 e 2025.';
}

// Se houve erros, voltar para o formulário
if ($errors) {
    $_SESSION['form_errors'] = $errors;
    $_SESSION['form_data'] = $_POST;
    header('Location: cadastro_veiculo.php');
    exit;
}

// Verificar se placa já existe
$check_stmt = $mysqli->prepare("SELECT id FROM veiculos WHERE placa = ?");
$check_stmt->bind_param('s', $placa);
$check_stmt->execute();
$check_stmt->store_result();

if ($check_stmt->num_rows > 0) {
    $check_stmt->close();
    $_SESSION['form_errors'] = ['Placa já cadastrada no sistema.'];
    $_SESSION['form_data'] = $_POST;
    header('Location: cadastro_veiculo.php');
    exit;
}
$check_stmt->close();

// Inserir no banco com prepared statement
$sql = "INSERT INTO veiculos (marca, modelo, cor, proprietario, placa, ano_fabricacao) VALUES (?, ?, ?, ?, ?, ?)";
if ($stmt = $mysqli->prepare($sql)) {
    $stmt->bind_param('sssssi', $marca, $modelo, $cor, $proprietario, $placa, $ano);
    
    if ($stmt->execute()) {
        // Sucesso - mostrar página de confirmação
        $novo_id = $stmt->insert_id;
        $stmt->close();
        
        // Buscar dados do veículo cadastrado
        $result = $mysqli->query("SELECT * FROM veiculos WHERE id = $novo_id");
        $veiculo = $result->fetch_assoc();
        $result->close();
        
        // Mostrar página de confirmação
        ?>
        <!DOCTYPE html>
        <html lang="pt-br">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Veículo Cadastrado - Sistema Veículos</title>
            <style>
                /* CSS igual ao do formulário */
                * { margin: 0; padding: 0; box-sizing: border-box; }
                :root {
                    --primary: #2563eb; --primary-dark: #1d4ed8; --secondary: #64748b;
                    --success: #10b981; --danger: #ef4444; --light: #f8fafc; --dark: #1e293b;
                    --border: #e2e8f0; --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
                }
                body {
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    min-height: 100vh; line-height: 1.6; color: var(--dark); padding: 20px;
                }
                .dashboard-container { max-width: 1200px; margin: 0 auto; }
                .header {
                    background: white; padding: 1.5rem 2rem; border-radius: 12px;
                    box-shadow: var(--shadow); margin-bottom: 2rem;
                    display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;
                }
                .header h1 { color: var(--dark); font-size: 2rem; }
                .user-info { display: flex; align-items: center; gap: 1rem; flex-wrap: wrap; }
                .btn {
                    padding: 0.75rem 1.5rem; border: none; border-radius: 6px; font-size: 0.95rem;
                    font-weight: 500; cursor: pointer; transition: all 0.3s; text-decoration: none;
                    display: inline-flex; align-items: center; gap: 0.5rem; font-family: inherit;
                }
                .btn-primary { background: var(--primary); color: white; }
                .btn-primary:hover { background: var(--primary-dark); transform: translateY(-1px); }
                .btn-secondary { background: var(--secondary); color: white; }
                .confirmation-container {
                    max-width: 600px; margin: 0 auto; background: white; padding: 2rem;
                    border-radius: 12px; box-shadow: var(--shadow);
                }
                .alert-success {
                    background: #f0fdf4; border: 1px solid #bbf7d0; color: var(--success);
                    padding: 1rem; border-radius: 6px; margin-bottom: 2rem; text-align: center;
                }
                .vehicle-details { margin: 2rem 0; }
                .detail-table {
                    width: 100%; border-collapse: collapse; margin-top: 1rem;
                }
                .detail-table td { padding: 0.75rem; border-bottom: 1px solid var(--border); }
                .detail-table td:first-child { font-weight: 600; width: 40%; }
                .actions { display: flex; gap: 1rem; margin-top: 2rem; }
                @media (max-width: 768px) {
                    .header { flex-direction: column; text-align: center; }
                    .user-info { justify-content: center; }
                    .actions { flex-direction: column; }
                }
            </style>
        </head>
        <body>
            <div class="dashboard-container">
                <div class="header">
                    <h1>✅ Veículo Cadastrado</h1>
                    <div class="user-info">
                        <span>Usuário: <strong><?= htmlspecialchars($_SESSION['user']) ?></strong></span>
                        <a href="dashboard.php" class="btn btn-primary">📋 Ver Todos Veículos</a>
                        <a href="logout.php" class="btn btn-secondary">🚪 Sair</a>
                    </div>
                </div>

                <div class="confirmation-container">
                    <div class="alert-success">
                        <h3>🎉 Veículo cadastrado com sucesso!</h3>
                    </div>

                    <div class="vehicle-details">
                        <h3>Dados do Veículo Cadastrado:</h3>
                        <table class="detail-table">
                            <tr><td>ID:</td><td><?= $veiculo['id'] ?></td></tr>
                            <tr><td>Marca:</td><td><?= htmlspecialchars($veiculo['marca']) ?></td></tr>
                            <tr><td>Modelo:</td><td><?= htmlspecialchars($veiculo['modelo']) ?></td></tr>
                            <tr><td>Cor:</td><td><?= htmlspecialchars($veiculo['cor']) ?></td></tr>
                            <tr><td>Proprietário:</td><td><?= htmlspecialchars($veiculo['proprietario']) ?></td></tr>
                            <tr><td>Placa:</td><td><strong><?= htmlspecialchars($veiculo['placa']) ?></strong></td></tr>
                            <tr><td>Ano de Fabricação:</td><td><?= $veiculo['ano_fabricacao'] ?></td></tr>
                            <tr><td>Data de Cadastro:</td><td><?= date('d/m/Y H:i', strtotime($veiculo['data_cadastro'])) ?></td></tr>
                        </table>
                    </div>

                    <div class="actions">
                        <a href="cadastro_veiculo.php" class="btn btn-primary">➕ Cadastrar Outro Veículo</a>
                        <a href="dashboard.php" class="btn btn-secondary">📋 Ver Lista Completa</a>
                    </div>
                </div>
            </div>
        </body>
        </html>
        <?php
    } else {
        // Erro na execução
        if ($mysqli->errno === 1062) {
            $_SESSION['form_errors'] = ['Placa já cadastrada no sistema.'];
        } else {
            $_SESSION['form_errors'] = ['Erro ao salvar veículo: ' . $mysqli->error];
        }
        $_SESSION['form_data'] = $_POST;
        header('Location: cadastro_veiculo.php');
    }
    $stmt->close();
} else {
    $_SESSION['form_errors'] = ['Erro no sistema. Tente novamente.'];
    header('Location: cadastro_veiculo.php');
}

$mysqli->close();
?>